﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PasajeMicro : Pasaje
    {
        private Servicio tipoServicio;

        public PasajeMicro(string origen, string destino, Pasajero pasajero,
                    float precio, DateTime fecha, Servicio tipoServicio) 
                    : base(origen, destino, pasajero, precio, fecha)
        {
            this.tipoServicio = tipoServicio;
        }

        public override string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine(base.Mostrar());
            retorno.AppendLine("Tipo de servicio: " + this.tipoServicio);


            return retorno.ToString();
        }

        public override float PrecioFinal
        {
            get
            {
                if (this.tipoServicio == Servicio.SemiCama)
                {
                    return Precio * (float)0.90;
                }
                else if (this.tipoServicio == Servicio.Ejecutivo)
                {
                    return Precio * (float)0.80;
                }
                else
                {
                    return Precio;
                }
            }
        }
    }
}
