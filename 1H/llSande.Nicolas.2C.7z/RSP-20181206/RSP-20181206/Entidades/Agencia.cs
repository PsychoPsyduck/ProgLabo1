﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoMensaje(string mensaje);

    public class Agencia
    {
        private string nombre;
        private List<Pasaje> pasajesVendidos;

        public string Nombre { get => nombre; set => nombre = value; }
        public List<Pasaje> PasajesVendidos { get => pasajesVendidos; set => pasajesVendidos = value; }

        public static event DelegadoMensaje informar;

        private Agencia()
        {
            this.pasajesVendidos = new List<Pasaje>();
        }

        public Agencia(string nombre)
        {
            this.Nombre = nombre;
        }

        public static bool operator ==(Agencia a, Pasaje p)
        {
            foreach (Pasaje pas in a.pasajesVendidos)
            {
                if(pas == p)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Agencia a, Pasaje p)
        {
            if (!(a == p))
            {
                return true;
            }
            return false;
        }

        public static Agencia operator +(Agencia a, Pasaje p)
        {
            if(a != p)
            {
                a.pasajesVendidos.Add(p);
                informar.Invoke("Pasaje emitido correctamente");
            }
            else
            {
                informar.Invoke("Pasaje ya fue emitido con anterioridad");
            }
            return a;
        }

        public float CalcularGanancia()
        {
            float retorno = 0;

            foreach(Pasaje p in pasajesVendidos)
            {
               retorno =+ p.PrecioFinal;
            }
            return retorno;
        }

        public static explicit operator string(Agencia a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Agencia: " + a.Nombre);
            sb.AppendLine("Pasajes vendidos:");
            foreach (Pasaje p in a.PasajesVendidos)
            {
                sb.AppendLine(p.Mostrar());
            }
            sb.AppendLine("Ganancia: " + a.CalcularGanancia());

            return sb.ToString();
        }
    }
}
