﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PasajeAvion : Pasaje
    {
        private int cantidadEscalas;

        public PasajeAvion(string origen, string destino, Pasajero pasajero,
                    float precio, DateTime fecha, int cantidadEscalas) 
                    : base(origen, destino, pasajero, precio, fecha)
        {
            this.cantidadEscalas = cantidadEscalas;
        }

        public override string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine(base.Mostrar());
            retorno.AppendLine("Cantidad de escalas: " + this.cantidadEscalas);


            return retorno.ToString();
        }

        public override float PrecioFinal
        {
            get
            {
                if(this.cantidadEscalas == 1)
                {
                    return Precio * (float)0.90;
                }
                else if(this.cantidadEscalas == 2)
                {
                    return Precio * (float)0.80;
                }
                else
                {
                    return Precio * (float)0.70;
                }
            }
        }
    }
}
