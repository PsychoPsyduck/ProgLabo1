﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public class UsuarioDAO
    {
        private string cadenaDeConexion;
        private SqlCommand comando;
        private SqlConnection conexion;

        public UsuarioDAO()
        {
            cadenaDeConexion = "Data Source =.\\SQLEXPRESS; Initial Catalog = patentes-sp-2018; Integrated Security = True;";
            comando = new SqlCommand();
            conexion = new SqlConnection(cadenaDeConexion);
        }

        public bool Guardar(Usuario u)
        {
                try
                {
                    
                    this.conexion.Open();
                    string insertComando = String.Format("INSERT INTO final-20180802 (patente,tipo) VALUES('" + u.Nombre + "','" + u.Clave + "')");
                    this.comando = new SqlCommand(insertComando, this.conexion);
                    this.comando.ExecuteNonQuery();
                    return false;
                }
                catch (Exception e)
                {
                    return false;
                    throw e;
                }
                finally
                {
                    if (this.conexion.State == System.Data.ConnectionState.Open)
                    {
                        this.conexion.Close();
                    }
                }
        }

        public Usuario Leer(string usuario, string clave)
        {
            this.conexion.Open();
            Usuario usuarios = default(Usuario);
            this.comando.CommandText = String.Format("SELECT * FROM final-20180802");
            this.comando.Connection = this.conexion;
            SqlDataReader dataReader = comando.ExecuteReader();

            
            try
            {
                while (dataReader.Read())
                {
                    usuarios = new Usuario(dataReader["nombre"].ToString(), dataReader["clave"].ToString());
                    if(usuarios.Nombre == usuario && usuarios.Clave == clave)
                    {
                        return usuarios;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            dataReader.Close();
            return usuarios;

        }
    }
}
