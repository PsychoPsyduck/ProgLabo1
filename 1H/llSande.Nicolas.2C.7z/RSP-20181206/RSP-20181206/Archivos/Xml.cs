﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T>
    {
        public void Guardar(string destino, T datos)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + destino;

            if (File.Exists(path))
            {
                File.Create(path);
            }

            XmlWriter xmlWriter = XmlWriter.Create(destino);
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            try
            {
                serializer.Serialize(xmlWriter, datos);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                xmlWriter.Close();
            }
        }

        public T Leer(string origen)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + origen;

            if (!File.Exists(path))
            {
                T datos = default(T);
                return datos;
            }

            XmlReader xmlReader = XmlReader.Create(origen);
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            try
            {
                T datos = default(T);
                return datos = (T)serializer.Deserialize(xmlReader);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                xmlReader.Close();
            }
        }
    }
}
