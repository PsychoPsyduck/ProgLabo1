#include <stdio.h>
#include <stdlib.h>
#define TAM 3

typedef struct
{
    int legajo;
    int nota1;
    int nota2;
    float promedio;
    char nombre[50];
}eAlumno;

void mostrarAlumno(eAlumno);
void mostrarTodosLosAlumnos(eAlumno[], int);
void cargarAlumnos(eAlumno[], int);

int main()
{

    eAlumno listaAlumnos[TAM];

    cargarAlumnos(listaAlumnos,TAM);
   mostrarTodosLosAlumnos(listaAlumnos, TAM);


    return 0;
}

void cargarAlumnos(eAlumno lista[], int tam)
{
     int i;

    for(i=0; i<tam; i++)
    {
        printf("IIngrese legajo: ");
        scanf("%d", &lista[i].legajo);
        printf("IIngrese nota 1: ");
        scanf("%d", &lista[i].nota1);

        printf("IIngrese nota 2: ");
        scanf("%d", &lista[i].nota2);

        printf("IIngrese nombre: ");
        fflush(stdin);
       gets(lista[i].nombre);

       lista[i].promedio=(float) (lista[i].nota1+lista[i].nota2)/2;
    }
}


void mostrarTodosLosAlumnos(eAlumno lista[], int tam)
{
    int i;
     for(i=0; i<tam; i++)
    {
        mostrarAlumno(lista[i]);
    }
}
void mostrarAlumno(eAlumno alumno)
{
    printf("%d--%d--%d--%f--%s\n", alumno.legajo, alumno.nota1,alumno.nota2,alumno.promedio, alumno.nombre);
}
