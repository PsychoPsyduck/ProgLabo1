#include <stdio.h>
#include <stdlib.h>

void cargarVector(int[], int);
void mostrarVector(int[], int);



int main()
{
    int vector[5];

   cargarVector(vector, 5);
    mostrarVector(vector,5);

    return 0;
}

void cargarVector(int vec[], int tam)
{

     int i;

    for(i=0; i<tam; i++)
    {
        printf("Ingrese un numero: ");
        scanf("%d", &vec[i]);
    }
}

void mostrarVector(int vec[], int tam)
{
     int i;

    for(i=0; i<tam; i++)
    {
        printf("%d\n", vec[i]);
    }

}
