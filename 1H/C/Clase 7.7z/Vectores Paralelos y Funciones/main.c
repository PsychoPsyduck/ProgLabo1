#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM 3

void mostrarAlumnos(int[], int[], int[], float[], char[][50], int);

int main()
{
    int leg[TAM]={100,101,102}, n1[TAM]={10,8,9}, n2[TAM]={4,2,3}, auxInt;
    float prom[TAM]={7,5,6}, auxFloat;
    char nombre[TAM][50]={"Luis","Maria","Pedro"}, auxString[50];
    int i, j;
    int flag=0;
    char rta;
    int opcion;

    do
    {
        printf("1.Cargar\n2.Mostrar\n3.Ordenar\n4.Modificar\n8.Salir\nElija una Opcion: ");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            for(i=0; i<TAM; i++)
            {
                printf("Ingrese legajo: ");
                scanf("%d", &leg[i]);

                printf("Ingrese su nombre: ");
                fflush(stdin);
                gets(nombre[i]);

                printf("Ingrese Nota 1: ");
                scanf("%d", &n1[i]);


                printf("Ingrese Nota 2: ");
                scanf("%d", &n2[i]);

                prom[i] = (float)(n1[i]+n2[i])/2;

            }
            break;
        case 2:

            mostrarAlumnos(leg,n1,n2,prom,nombre,TAM);
            break;

        case 3:

            for(i=0; i<TAM-1; i++)
            {
                for(j=i+1; j<TAM; j++)
                {
                    if(strcmp(nombre[i], nombre[j])>0)
                    {
                        //auxString
                        strcpy(auxString, nombre[i]);
                        strcpy(nombre[i], nombre[j]);
                        strcpy(nombre[j],auxString);

                        auxInt = leg[i];
                        leg[i] = leg[j];
                        leg[j] = auxInt;

                        auxInt = n1[i];
                        n1[i] = n1[j];
                        n1[j] = auxInt;

                        auxInt = n2[i];
                        n2[i] = n2[j];
                        n2[j] = auxInt;

                        auxFloat = prom[i];
                        prom[i] = prom[j];
                        prom[j] = auxFloat;

                    }
                }
            }

            break;

        case 4:

            printf("Ingrese el legajo: ");
            scanf("%d", &auxInt);

            for(i=0; i<TAM; i++)
            {
                if(leg[i] == auxInt)//Si existe
                {
                    flag=1;
                    printf("%d--%s--%d--%d--%f\n", leg[i], nombre[i], n1[i], n2[i], prom[i]);
                    printf("Ingrese la nueva nota (Nota 1): ");
                    scanf("%d", &auxInt);
                    printf("Esta seguro de modificar la nota? ");
                    rta = getche();
                    if(rta=='s')
                    {
                        n1[i]=auxInt;
                        prom[i] = (float)(n1[i]+n2[i])/2;
                    }
                    else
                    {
                        printf("Accion cancelada por el usuario");
                    }

                    break;
                }

            }
            if(flag==0)
            {

                    printf("\nLegajo Inexistente!!!\n");

            }



            break;

        }

    }
    while(opcion!=8);

    return 0;
}

void mostrarAlumnos(int legajos[], int nota1[], int nota2[], float promedio[], char nombres[][50], int t)
{
    int i;
     for(i=0; i<t; i++)
            {
                printf("%d--%s--%d--%d--%f\n", legajos[i], nombres[i], nota1[i], nota2[i], promedio[i]);
            }
}
