#include <stdio.h>
#include <stdlib.h>
#include "sort.h"

int main()
{
    int arrayEdades[11] = {22,56,55,66,29};
    char arrayNombres[11][50] = {"Juan","Pedro","Jose","Luis","Diego"};


    //sort_mostrarArrayEnteros(arrayEdades,5);
    //sort_mostrarArrayCadenaCaracteres(arrayNombres,5);
    sort_mostrarArrayStringInt(arrayNombres,arrayEdades,5);
    printf("\n\n");

    /*if(!sort_ordenarArrayEnteros(arrayEdades,5,1))
    {
        sort_mostrarArrayEnteros(arrayEdades,5);
        printf("\n\n");
    }
    else
    {
        printf("ERROR");
    }

    if(!sort_ordenarArrayCadenaCaracteres(arrayNombres,5,1))
    {
        sort_mostrarArrayCadenaCaracteres(arrayNombres,5);
        printf("\n\n");
    }
    else
    {
        printf("ERROR");
    }
*/
    if(!sort_ordenarArrayStringInt(arrayNombres,arrayEdades,5,1))
    {
        //sort_mostrarArrayEnteros(arrayEdades,5);
        //sort_mostrarArrayCadenaCaracteres(arrayNombres,5);
        sort_mostrarArrayStringInt(arrayNombres,arrayEdades,5);
        printf("\n\n");
    }
    else
    {
        printf("ERROR");
    }
    return 0;
}
