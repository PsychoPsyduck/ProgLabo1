
int sort_ordenarArrayEnteros(int* array,int cantidadElementos, int flagOrden);
int sort_mostrarArrayEnteros(int* array, int cantidadElementos);
int sort_ordenarArrayCadenaCaracteres(char array[][50], int cantidadElementos, int flagOrden);
int sort_mostrarArrayCadenaCaracteres(char array[][50], int cantidadElementos);
int sort_ordenarArrayStringInt(char arrayStr[][50], int arrayInt[], int cantidadElementos, int flagOrden);
int sort_mostrarArrayStringInt(char arrayStr[][50],int arrayInt[], int cantidadElementos);
